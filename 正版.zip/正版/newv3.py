# -*- coding: utf-8 -*-
# Support <-> ZNF TEAM BOTZ ===>##
import angrust
from angrust import *
from ang.ttypes import *
from datetime import datetime
import pytz, time, random, multiprocessing, sys, json, codecs, threading, glob, re, string, asyncio, os, requests, subprocess, six, urllib, urllib.parse
from time import sleep
from bs4 import BeautifulSoup
#import pyimgflip
#import youtube_dl
#-----------------------------------------------------------------------登入

#==============[●●●●●●]==============#
print ("Login Succes")


#-------------------------------------------------------------設定MID
clMID = cl.getProfile().mid
k1MID = k1.getProfile().mid
k2MID = k2.getProfile().mid
k3MID = k3.getProfile().mid
k4MID = k4.getProfile().mid
k5MID = k5.getProfile().mid
k6MID = k6.getProfile().mid
k7MID = k7.getProfile().mid
k8MID = k8.getProfile().mid
q1MID = q1.getProfile().mid
q2MID = q2.getProfile().mid
q3MID = q3.getProfile().mid

Bots = [clMID,k1MID,k2MID,k3MID,k4MID,k5MID,k6MID,k7MID,k8MID,q1MID,q2MID,q3MID]
print("MID設定成功")
#--------------------------------------------------------------不明
oepoll = OEPoll(cl)
oepoll1 = OEPoll(k1)
oepoll2 = OEPoll(k2)
oepoll3 = OEPoll(k3)
oepoll4 = OEPoll(k4)
oepoll5 = OEPoll(k5)
oepoll6 = OEPoll(k6)
oepoll7 = OEPoll(k7)
oepoll8 = OEPoll(k8)
oepoll9 = OEPoll(q1)
oepoll10 = OEPoll(q2)
oepoll11= OEPoll(q3)


#-------------------------------------------------------------json設定
ban = json.load(codecs.open("ban.json","r","utf-8"))
settings = json.load(codecs.open("temp.json","r","utf-8"))
#--------------------------------------------------------------設定定義
def restartBot():
    print ("[ INFO ] BOT RESETTED")
    backupData()
    python = sys.executable
    os.execl(python, python, *sys.argv)
def backupData():#--------------------------------------------------------------存檔
    try: 
        json.dump(ban, codecs.open('ban.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False) 
        json.dump(settings,codecs.open('temp.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False
def cek(mid):#-----------------------------------------------------------------檢查MID 123
    if mid  in (ban["admin"] + ban["owners"] + Bots):
        return True
    else:
        return False
def restartBot():#---------------------------------------------------------------重啟
    python = sys.executable
    os.execl(python, python, *sys.argv)
def runtime(secs):#--------------------------------------------------------------運行時間
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)
def logError(text):#-----------------------------------------錯誤紀錄
    cl.log("[ ERROR ] " + str(text))
    time_ = datetime.now()
    with open("errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))
def linetalk(op):
    try:
        if op.type == 0:
            return
        if op.type == 13:
            if clMID in op.param3:
                if cek(op.param2):
                    cl.acceptGroupInvitation(op.param1)
                    ang = [clMID,k1MID,k2MID,k3MID,k4MID,k5MID,k6MID,k7MID,k8MID,q1MID,q2MID,q3MID]
                    cl.inviteIntoGroup(op.param1, ang)
                    k1.acceptGroupInvitation(op.param1)
                    k2.acceptGroupInvitation(op.param1)
                    k3.acceptGroupInvitation(op.param1)
                    k4.acceptGroupInvitation(op.param1)
                    k5.acceptGroupInvitation(op.param1)
                    k6.acceptGroupInvitation(op.param1)
                    k7.acceptGroupInvitation(op.param1)
                    k8.acceptGroupInvitation(op.param1)
                    q1.acceptGroupInvitation(op.param1)
                    q2.acceptGroupInvitation(op.param1)
                    q3.acceptGroupInvitation(op.param1)

        if op.type == 11:#QR
            if not cek(op.param2):
                try:
                    q3.kickoutFromGroup(op.param1,[op.param2])
                    q3.reissueGroupTicket(op.param1)
                    X = q3.getGroup(op.param1)
                    X.preventedJoinByTicket = True
                    q3.updateGroup(X)
                except:
                    try:
                        q2.kickoutFromGroup(op.param1,[op.param2])
                        q2.reissueGroupTicket(op.param1)
                        X = q2.getGroup(op.param1)
                        X.preventedJoinByTicket = True
                        q2.updateGroup(X)
                    except:
                       pass
                ban["blacklist"][op.param2] = True
                json.dump(ban, codecs.open('ban.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False)
        if op.type == 13:#邀請
            if not cek(op.param2):
                X = q1.getCompactGroup(op.param1)
                if X.invitee is not None:
                    gInviMids = [contact.mid for contact in X.invitee]
                    for target in pipo:
                        if target in op.param3:
                            q1.cancelGroupInvitation(op.param1,[target])
                            q1.kickoutFromGroup(op.param1,[target])
                else:
                    pass   
                ban["blacklist"][op.param2] = True
                json.dump(ban, codecs.open('ban.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False)
        elif op.type == 19: 
            if q1MID in op.param3:
                try:
                    q2.inviteIntoGroup(op.param1,[op.param3])
                    ql.acceptGroupInvitation(op.param1)
                except:
                    try:
                        q3.inviteIntoGroup(op.param1,[op.param3])
                        ql.acceptGroupInvitation(op.param1)
                    except:
                        pass
                    else:
                        pass
            elif q2MID in op.param3:
                try:
                    q3.inviteIntoGroup(op.param1,[op.param3])
                    q2.acceptGroupInvitation(op.param1)
                except:
                    try:
                        q1.inviteIntoGroup(op.param1,[op.param3])
                        q2.acceptGroupInvitation(op.param1)
                    except:
                        pass
                    else:
                        pass
            elif q3MID in op.param3:
                try:
                    q1.inviteIntoGroup(op.param1,[op.param3])
                    q3.acceptGroupInvitation(op.param1)
                except:
                    try:
                        q2.inviteIntoGroup(op.param1,[op.param3])
                        q3.acceptGroupInvitation(op.param1)
                    except:
                        pass
            elif not cek(op.param2):
                ban["blacklist"][op.param2] = True
                json.dump(ban, codecs.open('ban.json','w','utf-8'), sort_keys=True, indent=4, ensure_ascii=False)
            
        elif (op.type == 25 or op.type == 26) and op.message.contentType == 0:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != cl.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 0:
                if text is None:
                    return
            if sender in ban["owners"]:
                if text.lower() == 'rebot':
                    cl.sendMessage(to, "重新啟動中...")
                    restartBot()
                if text.lower() == 'cadmin':
                    ban["admin"] = []
                    cl.sendMessage(msg.to,"done")
                if msg.text.lower().startswith("mid "):#看mid
                    key = eval(msg.contentMetadata["MENTION"])
                    key1 = key["MENTIONEES"][0]["M"]
                    mi = cl.getContact(key1)
                    cl.sendMessage(msg.to, "名稱 : "+str(mi.displayName)+"\nMID : " +key1)
                    cl.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                if text.lower() == 'adminlist':
                    if ban["admin"] == []:
                        cl.sendMessage(to,"no admin")
                    else:
                        mc = "╔══[ 權限名單 ]"
                        for mi_d in ban["admin"]:
                            mc += "\n╠ "+cl.getContact(mi_d).displayName
                        cl.sendMessage(to,mc + "\n╚══[ Master Zero ]")
                if text.lower() == 'ban on':
                    settings["ban"] = True
                    cl.sendMessage(msg.to,"send the contact")
                if text.lower() == 'unban on':
                    settings["unban"] = True
                    cl.sendMessage(msg.to,"send the contact")
                if text.lower() == 'adminadd on':
                    settings["adminadd"] = True
                    cl.sendMessage(msg.to,"send the contact")
                if text.lower() == 'admindel on':
                    settings["admindel"] = True
                    cl.sendMessage(msg.to,"send the contact")
                if text.lower() =='hi':
                    cl.sendMessage(to,"test")
                if text.lower() == 'cban':
                    ban["blacklist"] = {}
                    ang = cl.getContacts(ban["blacklist"])
                    mc = "%i Blacklist " % len(ang)
                    cl.sendMessage(msg.to,"done " +mc)
                if text.lower() == '/bye':
                    G = cl.getGroup(msg.to)
                    cl.sendMessage(msg.to, "離開群組 ")
                    cl.leaveGroup(msg.to)
                if text.lower() == 'banlist':
                    if ban["blacklist"] == {}:
                        cl.sendMessage(to,"╔══════════════\n╠⚜ 無黑名單\n╚══════════════")
                    else:
                        mc = "╔══════════════\n黑單\n╠══════════════"
                        for mi_d in ban["blacklist"]:
                            mc += "\n╠⚜ "+cl.getContact(mi_d).displayName
                        cl.sendMessage(msg.to,mc + "\n╚══════════════")
                if text.lower() == 'bot':
                    ma = ""
                    a = 0
                    for m_id in Bots:
                        a = a + 1
                        end = '\n'
                        ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                    cl.sendMessage(msg.to,"  bot名單\n\n"+ma+"\nTotal : %s" %(str(len(Bots))))
            if sender in ban["admin"] or sender in ban["owners"]:
                if text.lower() in ['speed','sp']:
                    start = time.time()
                    cl.sendMessage(to, "檢查中...")
                    elapsed_time = time.time() - start
                    cl.sendMessage(to,format(str(elapsed_time)) + "秒")
                if text.lower() =='join':
                    G = cl.getGroup(msg.to)
                    G.preventedJoinByTicket = False
                    cl.updateGroup(G)
                    Ticket = cl.reissueGroupTicket(msg.to)
                    for x in [k1,k2,k3,k4,k5,k6,k7,k8,q1,q2,q3]:
                        x.acceptGroupInvitationByTicket(to,Ticket)
                    G.preventedJoinByTicket = True
                    cl.updateGroup(G)
                if text.lower() == 'bye':
                    for x in [k1,k2,k3,k4,k5,k6,k7,k8,q1,q2,q3]:
                        x.leaveGroup(msg.to)
        if op.type == 25 or op.type ==26:#友資區
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0:
                if sender != cl.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 13:
                if settings["ban"] ==True:
                    if msg._from in ban["owners"]:
                        ban["blacklist"][msg.contentMetadata["mid"]]=True
                        cl.sendMessage(msg.to,"done")
                        settings["ban"] =False
                if settings["unban"] ==True:
                    if msg._from in ban["owners"]:
                        del ban["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"done")
                        settings["unban"] =False
                if settings["adminadd"] ==True:
                    if msg._from in ban["owners"]:
                        inkey = msg.contentMetadata["mid"]
                        ban["admin"].append(str(inkey))
                        cl.sendMessage(msg.to,"done")
                        settings["adminadd"] = False
                if settings["admindel"] ==True:
                    if msg._from in ban["owners"]:
                        inkey = msg.contentMetadata["mid"]
                        ban["admin"].remove(str(inkey))
                        cl.sendMessage(msg.to,"done")
                        settings["admindel"] = False
    except Exception as error:
        print(error)

def jkbot(op):
    try:
        if op.type == 0:
            return
        elif op.type == 17:
            if not cek(op.param2):
                try:
                    k5.kickoutFromGroup(op.param1,[op.param2])
                except:
                    try:
                        k6.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            k7.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                k8.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                pass
                            else:
                                pass
        elif op.type == 19:
            if k5MID in op.param3:
                try:
                    k6.inviteIntoGroup(op.param1,[op.param3])
                    k5.acceptGroupInvitation(op.param1)
                except:
                    try:
                        k7.inviteIntoGroup(op.param1,[op.param3])
                        k5.acceptGroupInvitation(op.param1)
                    except:
                        pass

            elif k6MID in op.param3:
                try:
                    k7.inviteIntoGroup(op.param1,[op.param3])
                    k6.acceptGroupInvitation(op.param1)
                except:
                    try:
                        k8.inviteIntoGroup(op.param1,[op.param3])
                        k6.acceptGroupInvitation(op.param1)
                    except:
                       pass
            elif k7MID in op.param3:
                try:
                    k8.inviteIntoGroup(op.param1,[op.param3])
                    k7.acceptGroupInvitation(op.param1)
                except:
                    try:
                        k5.inviteIntoGroup(op.param1,[op.param3])
                        k7.acceptGroupInvitation(op.param1)
                    except:
                       pass
            elif k8MID in op.param3:
                try:
                    k5.inviteIntoGroup(op.param1,[op.param3])
                    k8.acceptGroupInvitation(op.param1)
                except:
                    try:
                        k6.inviteIntoGroup(op.param1,[op.param3])
                        k8.acceptGroupInvitation(op.param1)
                    except:
                       pass
    except Exception as error:
        print(error)
def probot(op):
    try:
        if op.type == 0:
            return
        if op.type == 19:
            if cek(op.param3):
                if k1MID in op.param3:
                    try:
                        k2.inviteIntoGroup(op.param1,[op.param3])
                        k1.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            k3.inviteIntoGroup(op.param1,[op.param3])
                            k1.acceptGroupInvitation(op.param1)
                        except:
                            pass
                elif k2MID in op.param3:
                    try:
                        k3.inviteIntoGroup(op.param1,[op.param3])
                        k2.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            k4.inviteIntoGroup(op.param1,[op.param3])
                            k2.acceptGroupInvitation(op.param1)
                        except:
                            pass
                elif k3MID in op.param3:
                    try:
                        k4.inviteIntoGroup(op.param1,[op.param3])
                        k3.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            k1.inviteIntoGroup(op.param1,[op.param3])
                            k3.acceptGroupInvitation(op.param1)
                        except:
                            pass
                elif k4MID in op.param3:
                    try:
                        k1.inviteIntoGroup(op.param1,[op.param3])
                        k4.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            k2.inviteIntoGroup(op.param1,[op.param3])
                            k4.acceptGroupInvitation(op.param1)
                        except:
                            pass
            elif not cek(op.param3):
                if not cek(op.param2):
                    try:
                        k1.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            k2.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                k3.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    k4.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    pass
    except Exception as error:
        print(error)
def bot1run():
    while True:
        try:
            ops = oepoll.singleTrace(count=50)
            if ops is not None:
                for op in ops:
                    linetalk(op)
                    oepoll.setRevision(op.revision)
        except:
            pass
def bot2run():
    while True:
        try:
            ops = oepoll1.singleTrace(count=50)
            if ops is not None:
                for op in ops:
                    probot(op)
                    oepoll1.setRevision(op.revision)
        except:
            pass
def bot3run():
    while True:
        try:
            ops = oepoll5.singleTrace(count=50)
            if ops is not None:
                for op in ops:
                    jkbot(op)
                    oepoll5.setRevision(op.revision)
        except:
            pass
print("系統開始執行~")
thread1 = threading.Thread(target=bot1run)
thread2 = threading.Thread(target=bot2run)
thread3 = threading.Thread(target=bot3run)


thread1.start()
thread2.start()
thread3.start()

